import os

from dotenv import load_dotenv

load_dotenv()


class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY")
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    # PythonAnywhere'de "Force HTTPS" açıldığında .env içinde SECURE_COOKIES=1 yap.
    SESSION_COOKIE_SECURE = os.environ.get("SECURE_COOKIES") == "1"
    # Pilot yaş politikası (A1). Lab önerisi: 18.
    MIN_YAS = int(os.environ.get("MIN_YAS", "18"))


class TestConfig(Config):
    TESTING = True
    SECRET_KEY = "test-anahtari"
