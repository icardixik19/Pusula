"""Tema, yoğunluk ve profil oturum yardımcıları."""
from datetime import date

from flask import session

GUNLER = ["Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi", "Pazar"]
GUN_KISA = ["Pzt", "Sal", "Çar", "Per", "Cum", "Cmt", "Paz"]
AYLAR = ["Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz",
         "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"]

# Prototip profilleri. Yaş veya cinsiyetten ilgi çıkarılmaz; bunlar
# kullanıcı araştırmasıyla doğrulanacak örneklerdir.
ORNEK_PROFILLER = {
    "okul-spor": {
        "etiket": "Okul + spor",
        "ad": "Deniz",
        "moduller": ["okul", "spor"],
        "hedefler": {"okul": "sinav", "spor": "duzenli"},
        "yogunluk": "standart",
    },
    "is-finans": {
        "etiket": "İş + finans",
        "ad": "Selin",
        "moduller": ["is", "finans", "ogrenme"],
        "hedefler": {"is": "oncelik", "finans": "birikim"},
        "yogunluk": "standart",
    },
    "hareket-sade": {
        "etiket": "Hareket + sade görünüm",
        "ad": "Hüseyin",
        "moduller": ["spor", "beslenme"],
        "hedefler": {"spor": "duzenli", "beslenme": "su"},
        "yogunluk": "sade",
    },
}


_ORNEK_DURUMLAR = ["tamam", "kismen", "tamam", "yok", "tamam", "tamam"]
DURUM_METNI = {"tamam": "plan tamamlandı", "kismen": "plan kısmen tamamlandı",
               "yok": "kayıt yok", "bugun": "bugün", "plan": "henüz gelmedi"}


def hafta_seridi(gun=None):
    """Bugünü içeren pazartesi-pazar haftası. Geçmiş günlerin durumu [ÖRNEK]."""
    from datetime import timedelta
    gun = gun or date.today()
    pazartesi = gun - timedelta(days=gun.weekday())
    seri = []
    for i in range(7):
        g = pazartesi + timedelta(days=i)
        if g < gun:
            durum = _ORNEK_DURUMLAR[i % len(_ORNEK_DURUMLAR)]
        elif g == gun:
            durum = "bugun"
        else:
            durum = "plan"
        seri.append({"harf": GUN_KISA[i], "ad": GUNLER[i], "gun": g.day,
                     "durum": durum, "metin": DURUM_METNI[durum]})
    return seri


def bugun_metni(gun=None):
    gun = gun or date.today()
    return f"{gun.day} {AYLAR[gun.month - 1]} {GUNLER[gun.weekday()]}"


def aktif_profil():
    """Kurulumu bitiren kullanıcının profili; yoksa seçili örnek profil."""
    if session.get("profil"):
        return session["profil"], None
    anahtar = session.get("ornek", "okul-spor")
    if anahtar not in ORNEK_PROFILLER:
        anahtar = "okul-spor"
    return ORNEK_PROFILLER[anahtar], anahtar


def gorunum_baglami():
    return {
        "tema": session.get("tema", "sistem"),
        "yogunluk": session.get("yogunluk_tercih")
        or (session.get("profil") or {}).get("yogunluk", "standart"),
    }
