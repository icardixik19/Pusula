"""Modül kaydı.

Her modül: kimlik, ad, kısa açıklama, ikon adı, pusula yönü (derece)
ve kurulumda sunulan hazır hedefler. Kartlar şimdilik örnek veriden
(fixtures/kartlar.json) gelir; gerçek veritabanı bağlanınca yalnızca
kart_getir() değişir.
"""
import json
from pathlib import Path

MODULLER = {
    "okul": {
        "ad": "Okul",
        "aciklama": "Ders planı, sınavlar, ödevler",
        "yon": 0,
        "hedefler": [
            ("sinav", "Sınava düzenli hazırlanmak"),
            ("odev", "Ödevleri zamanında teslim etmek"),
            ("tekrar", "Konuları düzenli tekrar etmek"),
        ],
    },
    "is": {
        "ad": "İş",
        "aciklama": "Öncelikler, son tarihler, odak",
        "yon": 60,
        "hedefler": [
            ("oncelik", "Her gün en önemli 3 işi bitirmek"),
            ("odak", "Günde bir odak bloğu ayırmak"),
            ("mesai", "Mesaiyi zamanında bitirmek"),
        ],
    },
    "finans": {
        "ad": "Finans",
        "aciklama": "Gelir-gider, bütçe, birikim",
        "yon": 120,
        "hedefler": [
            ("birikim", "Belirli bir tutar biriktirmek"),
            ("butce", "Aylık bütçe sınırında kalmak"),
            ("takip", "Harcamalarımı görmek"),
        ],
    },
    "spor": {
        "ad": "Spor",
        "aciklama": "Antrenman, hareket, ilerleme",
        "yon": 180,
        "hedefler": [
            ("duzenli", "Düzenli hareket etmek"),
            ("guc", "Güçlenmek"),
            ("kondisyon", "Kondisyonumu artırmak"),
        ],
    },
    "beslenme": {
        "ad": "Beslenme",
        "aciklama": "Öğün düzeni, su, porsiyon",
        "yon": 240,
        "hedefler": [
            ("duzen", "Düzenli öğün yemek"),
            ("su", "Yeterli su içmek"),
            ("kayit", "Ne yediğimi görmek"),
        ],
    },
    "ogrenme": {
        "ad": "Öğrenme",
        "aciklama": "Yeni beceri, okuma, kurs",
        "yon": 300,
        "hedefler": [
            ("beceri", "Yeni bir beceri öğrenmek"),
            ("okuma", "Düzenli kitap okumak"),
            ("kurs", "Bir kursu bitirmek"),
        ],
    },
}

_KART_DOSYASI = Path(__file__).resolve().parent.parent / "fixtures" / "kartlar.json"


def _ornek_kartlar():
    with open(_KART_DOSYASI, encoding="utf-8") as f:
        return json.load(f)


def kucuk_adim(modul_id):
    """Modül için bugünün tek, küçük adımı. Şimdilik [ÖRNEK] veri."""
    return _ornek_kartlar().get("_kucuk_adim", {}).get(modul_id)


def kart_getir(modul_id):
    """Bir modülün kartlarını döndürür. Şimdilik [ÖRNEK] veri."""
    return [dict(k, modul=modul_id) for k in _ornek_kartlar().get(modul_id, [])]
