"""Kart motoru: kartları yapay zekâ olmadan, belirlenimli biçimde sıralar.

puan = temel + aciliyet(0-50) + hedef_eslesme(+20) + sabitli(+100) - yakin_goruldu(-15)

Eşitlikte kullanıcının modül sırası, sonra kart anahtarı belirler; böylece
aynı girdi her seferinde aynı sırayı verir. Cinsiyet bu hesaba GİRMEZ.
"""
from .modules import MODULLER, kart_getir

KART_TIPLERI = {"metrik", "liste", "ilerleme", "eylem"}
SINIR = {"standart": 4, "sade": 3}


def puanla(kart, hedefler, sabitli=(), goruldu=()):
    puan = int(kart.get("temel", 10))
    puan += max(0, min(50, int(kart.get("aciliyet", 0))))
    if kart.get("hedef") and kart["hedef"] == hedefler.get(kart["modul"]):
        puan += 20
    if kart["anahtar"] in sabitli:
        puan += 100
    if kart["anahtar"] in goruldu:
        puan -= 15
    return puan


def ana_ekran(profil, sabitli=(), goruldu=()):
    """Profilden (modüller, hedefler, yoğunluk) ana ekran kartlarını üretir.

    Döner: (one_cikan, gorunen, diger_moduller)
    """
    moduller = [m for m in profil.get("moduller", []) if m in MODULLER]
    hedefler = profil.get("hedefler", {})
    sira = {m: i for i, m in enumerate(moduller)}

    kartlar = []
    for m in moduller:
        for k in kart_getir(m):
            if k.get("tip") not in KART_TIPLERI:
                continue
            k["puan"] = puanla(k, hedefler, sabitli, goruldu)
            kartlar.append(k)

    kartlar.sort(key=lambda k: (-k["puan"], sira[k["modul"]], k["anahtar"]))

    # Her modülden en iyi kart; böylece bir modül ekranı tek başına doldurmaz.
    secilen, gorulen_modul = [], set()
    for k in kartlar:
        if k["modul"] not in gorulen_modul:
            secilen.append(k)
            gorulen_modul.add(k["modul"])

    sinir = SINIR.get(profil.get("yogunluk", "standart"), 4)
    gorunen = secilen[:sinir]
    diger = [k["modul"] for k in secilen[sinir:]]
    one_cikan = gorunen[0] if gorunen else None
    return one_cikan, gorunen[1:], diger
