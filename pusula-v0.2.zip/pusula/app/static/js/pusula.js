// Pusula prototip davranışları. Sayfa JS olmadan da çalışır.
(function () {
  const kok = document.documentElement;

  // Tema seçimi: kaydetmeden önce anında önizle.
  document.querySelectorAll("[data-tema-sec]").forEach((r) => {
    r.addEventListener("change", () => {
      if (r.value === "sistem") kok.removeAttribute("data-tema");
      else kok.setAttribute("data-tema", r.value);
    });
  });

  // Prototipte çalışmayan eylemler: ne olacağını söyle.
  const bildirim = document.getElementById("bildirim");
  let zaman;
  document.querySelectorAll("[data-prototip]").forEach((d) => {
    d.addEventListener("click", () => {
      bildirim.textContent = `“${d.textContent.trim()}” kayıtlar bağlandığında çalışacak.`;
      bildirim.classList.add("acik");
      clearTimeout(zaman);
      zaman = setTimeout(() => bildirim.classList.remove("acik"), 3200);
    });
  });

  // Küçük adım işaretlenince sakin bir onay.
  document.querySelectorAll("[data-adim]").forEach((k) => {
    k.addEventListener("change", () => {
      bildirim.textContent = k.checked ? "Küçük adım tamamlandı." : "İşaret kaldırıldı.";
      bildirim.classList.add("acik");
      clearTimeout(zaman);
      zaman = setTimeout(() => bildirim.classList.remove("acik"), 2400);
    });
  });

  // Hata özeti varsa odağı oraya taşı.
  const ozet = document.getElementById("hata-ozeti");
  if (ozet) ozet.focus();
})();
