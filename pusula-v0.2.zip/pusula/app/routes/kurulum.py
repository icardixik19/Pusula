"""Kurulum akışı: hesap + yaş → görünüm → cinsiyet → ilgi alanları → hedefler → önizleme.

Prototipte veriler oturumda (imzalı çerez) tutulur; veritabanı sonraki adımda gelir.
Doğum yılı saklanmaz, yalnız "yetişkin" sonucu saklanır (veri minimizasyonu).
"""
from datetime import date

from flask import (Blueprint, current_app, redirect, render_template, request,
                   session, url_for)

from ..core.cards import ana_ekran
from ..core.modules import MODULLER

bp = Blueprint("kurulum", __name__, url_prefix="/kurulum")

ADIMLAR = ["hesap", "gorunum", "cinsiyet", "ilgi", "hedef", "onizleme"]
CINSIYETLER = [("kadin", "Kadın"), ("erkek", "Erkek"),
               ("belirtmek_istemiyorum", "Belirtmek istemiyorum")]


def _taslak():
    return session.setdefault("taslak", {"moduller": [], "hedefler": {}})


def _kaydet(**degerler):
    t = _taslak()
    t.update(degerler)
    session["taslak"] = t
    session.modified = True


def _sonraki(adim):
    return redirect(url_for("kurulum.adim", adim=ADIMLAR[ADIMLAR.index(adim) + 1]))


def _sayfa(adim, **ek):
    return render_template(
        f"kurulum/{adim}.html", adim=adim, no=ADIMLAR.index(adim) + 1,
        toplam=len(ADIMLAR), taslak=_taslak(), moduller=MODULLER,
        onceki=ADIMLAR[ADIMLAR.index(adim) - 1] if adim != "hesap" else None, **ek)


@bp.route("/")
def baslangic():
    return redirect(url_for("kurulum.adim", adim="hesap"))


@bp.route("/<adim>", methods=["GET", "POST"])
def adim(adim):
    if adim not in ADIMLAR:
        return redirect(url_for("kurulum.baslangic"))
    if adim != "hesap" and not _taslak().get("yetiskin"):
        return redirect(url_for("kurulum.adim", adim="hesap"))
    return globals()[f"_adim_{adim}"]()


def _adim_hesap():
    if request.method == "GET":
        return _sayfa("hesap", hatalar={}, girilen={})

    ad = request.form.get("ad", "").strip()[:40]
    yil_metni = request.form.get("dogum_yili", "").strip()
    onay = request.form.get("yas_onay") == "evet"
    hatalar = {}
    bu_yil = date.today().year
    min_yas = current_app.config["MIN_YAS"]

    try:
        yil = int(yil_metni)
        if not 1900 <= yil <= bu_yil:
            raise ValueError
    except ValueError:
        yil = None
        hatalar["dogum_yili"] = f"Doğum yılını 4 rakamla yaz, örneğin {bu_yil - 30}."

    if yil is not None and bu_yil - yil < min_yas:
        session.pop("taslak", None)
        return render_template("kurulum/durdur.html", min_yas=min_yas)

    if not onay:
        hatalar["yas_onay"] = f"Devam etmek için {min_yas} yaşını doldurduğunu onayla."

    if hatalar:
        return _sayfa("hesap", hatalar=hatalar, girilen={"ad": ad, "dogum_yili": yil_metni}), 400

    _kaydet(ad=ad, yetiskin=True)
    return _sonraki("hesap")


def _adim_gorunum():
    if request.method == "POST":
        tema = request.form.get("tema")
        yogunluk = request.form.get("yogunluk")
        if tema in ("sistem", "acik", "koyu"):
            session["tema"] = tema
        if yogunluk in ("standart", "sade"):
            session["yogunluk_tercih"] = yogunluk
            _kaydet(yogunluk=yogunluk)
        return _sonraki("gorunum")
    return _sayfa("gorunum")


def _adim_cinsiyet():
    if request.method == "POST":
        secim = None if request.form.get("gec") else request.form.get("cinsiyet")
        _kaydet(cinsiyet=secim if secim in dict(CINSIYETLER) else None)
        return _sonraki("cinsiyet")
    return _sayfa("cinsiyet", secenekler=CINSIYETLER)


def _adim_ilgi():
    if request.method == "POST":
        secilen = [m for m in request.form.getlist("modul") if m in MODULLER]
        t = _taslak()
        hedefler = {m: h for m, h in t.get("hedefler", {}).items() if m in secilen}
        _kaydet(moduller=secilen, hedefler=hedefler)
        return _sonraki("ilgi")
    return _sayfa("ilgi")


def _adim_hedef():
    t = _taslak()
    if request.method == "POST":
        hedefler = {}
        for m in t.get("moduller", []):
            secim = request.form.get(f"hedef_{m}")
            gecerli = {h for h, _ in MODULLER[m]["hedefler"]}
            if secim in gecerli:
                hedefler[m] = secim
        _kaydet(hedefler=hedefler)
        return _sonraki("hedef")
    return _sayfa("hedef")


def _adim_onizleme():
    t = _taslak()
    if request.method == "POST":
        islem = request.form.get("islem", "")
        moduller = list(t.get("moduller", []))
        if islem.startswith(("yukari:", "asagi:")):
            yon, m = islem.split(":", 1)
            if m in moduller:
                i = moduller.index(m)
                j = i - 1 if yon == "yukari" else i + 1
                if 0 <= j < len(moduller):
                    moduller[i], moduller[j] = moduller[j], moduller[i]
                    _kaydet(moduller=moduller)
            return redirect(url_for("kurulum.adim", adim="onizleme") + "#sira")
        if islem == "basla":
            session["profil"] = {
                "ad": t.get("ad", ""),
                "moduller": moduller,
                "hedefler": t.get("hedefler", {}),
                "yogunluk": t.get("yogunluk", "standart"),
                "cinsiyet": t.get("cinsiyet"),
            }
            session.pop("taslak", None)
            return redirect(url_for("bugun.bugun"))
    one, digerleri, kalan = ana_ekran(t)
    return _sayfa("onizleme", one=one, digerleri=digerleri, kalan=kalan)
