from datetime import date

from flask import Blueprint, redirect, render_template, request, session, url_for

from ..core.cards import ana_ekran
from ..core.gorunum import ORNEK_PROFILLER, aktif_profil, bugun_metni, hafta_seridi
from ..core.modules import MODULLER, kucuk_adim

bp = Blueprint("bugun", __name__)


@bp.route("/bugun")
def bugun():
    profil, ornek = aktif_profil()
    one, digerleri, kalan = ana_ekran(profil)
    yon = MODULLER[one["modul"]]["yon"] if one else 0
    adim_modul = (digerleri[0] if digerleri else one or {}).get("modul")
    adim = {"modul": adim_modul, "metin": kucuk_adim(adim_modul)} if adim_modul else None
    return render_template(
        "bugun.html", profil=profil, ornek=ornek, ornekler=ORNEK_PROFILLER,
        one=one, digerleri=digerleri, kalan=kalan, yon=yon, moduller=MODULLER,
        tarih=bugun_metni(), hafta=hafta_seridi(), adim=adim,
        bugun_index=date.today().weekday(), sayfa="bugun")


@bp.route("/ornek/<anahtar>")
def ornek_sec(anahtar):
    if anahtar in ORNEK_PROFILLER:
        session.pop("profil", None)
        session["ornek"] = anahtar
        session["yogunluk_tercih"] = ORNEK_PROFILLER[anahtar]["yogunluk"]
    return redirect(url_for("bugun.bugun"))


@bp.route("/profil", methods=["GET", "POST"])
def profil():
    if request.method == "POST":
        tema = request.form.get("tema")
        yogunluk = request.form.get("yogunluk")
        if tema in ("sistem", "acik", "koyu"):
            session["tema"] = tema
        if yogunluk in ("standart", "sade"):
            session["yogunluk_tercih"] = yogunluk
            if session.get("profil"):
                p = session["profil"]
                p["yogunluk"] = yogunluk
                session["profil"] = p
        return redirect(url_for("bugun.profil", kaydedildi=1))
    p, ornek = aktif_profil()
    return render_template("profil.html", profil=p, ornek=ornek, sayfa="profil",
                           kaydedildi=request.args.get("kaydedildi"))


@bp.route("/sifirla", methods=["POST"])
def sifirla():
    session.clear()
    return redirect(url_for("kurulum.baslangic"))


@bp.route("/planim")
def planim():
    return render_template("yakinda.html", sayfa="planim", baslik="Planım",
                           mesaj="Haftalık plan, kayıtlar veritabanına bağlandığında burada olacak.")


@bp.route("/ilerleme")
def ilerleme():
    return render_template("yakinda.html", sayfa="ilerleme", baslik="İlerleme",
                           mesaj="Hedeflerindeki ilerleme, kayıtlar veritabanına bağlandığında burada olacak.")
