"""Pusula uygulama fabrikası.

PythonAnywhere'de wsgi.py bu dosyadaki create_app() fonksiyonunu çağırır.
"""
import os

from flask import Flask, redirect, url_for

from .config import Config


def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)

    if not app.config.get("SECRET_KEY"):
        raise RuntimeError(".env dosyasında SECRET_KEY tanımlı değil.")

    from .routes.kurulum import bp as kurulum_bp
    from .routes.bugun import bp as bugun_bp

    app.register_blueprint(kurulum_bp)
    app.register_blueprint(bugun_bp)

    from .core.gorunum import gorunum_baglami
    app.context_processor(gorunum_baglami)

    @app.route("/")
    def ana():
        return redirect(url_for("bugun.bugun"))

    @app.errorhandler(404)
    def bulunamadi(_e):
        from flask import render_template
        return render_template("hata.html", baslik="Sayfa bulunamadı",
                               mesaj="Aradığın sayfa yok ya da taşınmış."), 404

    return app
