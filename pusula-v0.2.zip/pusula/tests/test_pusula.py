from datetime import date

import pytest

from app import create_app
from app.config import TestConfig
from app.core.cards import ana_ekran, puanla


@pytest.fixture
def istemci():
    app = create_app(TestConfig)
    return app.test_client()


def _hesap(istemci, yil, onay=True):
    veri = {"ad": "Test", "dogum_yili": str(yil)}
    if onay:
        veri["yas_onay"] = "evet"
    return istemci.post("/kurulum/hesap", data=veri)


# --- Kart motoru ---

def test_ayni_girdi_hep_ayni_sira():  # K-12
    p = {"moduller": ["okul", "spor", "finans"], "hedefler": {"okul": "sinav"}}
    ilk = ana_ekran(p)
    for _ in range(5):
        assert ana_ekran(p) == ilk


def test_cinsiyet_kartlari_degistirmez():  # K-02
    ortak = {"moduller": ["spor", "beslenme"], "hedefler": {"spor": "duzenli"}}
    assert ana_ekran(dict(ortak, cinsiyet="kadin")) == ana_ekran(dict(ortak, cinsiyet="erkek"))


def test_standart_en_fazla_4_kart():  # K-05
    p = {"moduller": ["okul", "is", "finans", "spor", "beslenme", "ogrenme"], "hedefler": {}}
    one, digerleri, kalan = ana_ekran(p)
    assert 1 + len(digerleri) == 4
    assert len(kalan) == 2


def test_sade_en_fazla_3_kart():  # K-09
    p = {"moduller": ["okul", "is", "finans", "spor"], "hedefler": {}, "yogunluk": "sade"}
    one, digerleri, kalan = ana_ekran(p)
    assert 1 + len(digerleri) == 3


def test_hedef_eslesmesi_puan_ekler():
    kart = {"anahtar": "x", "modul": "spor", "temel": 10, "aciliyet": 0, "hedef": "guc"}
    assert puanla(kart, {"spor": "guc"}) - puanla(kart, {}) == 20


def test_aciliyet_50_ile_sinirli():
    kart = {"anahtar": "x", "modul": "spor", "temel": 0, "aciliyet": 999}
    assert puanla(kart, {}) == 50


def test_modulsuz_profil_bos_doner():  # K-04 (motor tarafı)
    assert ana_ekran({"moduller": []}) == (None, [], [])


# --- Kurulum ---

def test_yas_siniri_altinda_durdurur_ve_kaydetmez(istemci):  # K-03
    yanit = _hesap(istemci, date.today().year - 15)
    assert "yaş ve üstü için açık".encode() in yanit.data
    with istemci.session_transaction() as s:
        assert "taslak" not in s


def test_yas_onayi_olmadan_ilerlemez(istemci):
    yanit = _hesap(istemci, 1990, onay=False)
    assert yanit.status_code == 400


def test_dogum_yili_saklanmaz(istemci):
    _hesap(istemci, 1990)
    with istemci.session_transaction() as s:
        assert "1990" not in str(dict(s))
        assert s["taslak"]["yetiskin"] is True


def test_yas_kontrolu_atlanamaz(istemci):
    yanit = istemci.get("/kurulum/ilgi")
    assert yanit.status_code == 302 and yanit.location.endswith("/kurulum/hesap")


def test_cinsiyet_gecilebilir(istemci):  # K-01
    _hesap(istemci, 1990)
    istemci.post("/kurulum/cinsiyet", data={"cinsiyet": "kadin", "gec": "1"})
    with istemci.session_transaction() as s:
        assert s["taslak"]["cinsiyet"] is None


def test_geri_donuste_secimler_kaybolmaz(istemci):  # K-06
    _hesap(istemci, 1990)
    istemci.post("/kurulum/ilgi", data={"modul": ["okul", "spor"]})
    sayfa = istemci.get("/kurulum/ilgi").get_data(as_text=True)
    assert 'value="okul" checked' in sayfa and 'value="spor" checked' in sayfa


def test_tum_akis_ana_ekrani_kurar(istemci):
    _hesap(istemci, 1990)
    istemci.post("/kurulum/gorunum", data={"tema": "koyu", "yogunluk": "standart"})
    istemci.post("/kurulum/cinsiyet", data={"cinsiyet": "belirtmek_istemiyorum"})
    istemci.post("/kurulum/ilgi", data={"modul": ["finans", "okul"]})
    istemci.post("/kurulum/hedef", data={"hedef_finans": "birikim"})
    istemci.post("/kurulum/onizleme", data={"islem": "yukari:okul"})
    yanit = istemci.post("/kurulum/onizleme", data={"islem": "basla"})
    assert yanit.location.endswith("/bugun")
    with istemci.session_transaction() as s:
        assert s["profil"]["moduller"] == ["okul", "finans"]
    sayfa = istemci.get("/bugun").get_data(as_text=True)
    assert "Bugünün yönü" in sayfa


def test_gecersiz_modul_kabul_edilmez(istemci):
    _hesap(istemci, 1990)
    istemci.post("/kurulum/ilgi", data={"modul": ["okul", "<script>"]})
    with istemci.session_transaction() as s:
        assert s["taslak"]["moduller"] == ["okul"]


@pytest.mark.parametrize("anahtar", ["okul-spor", "is-finans", "hareket-sade"])
def test_ornek_profiller_acilir(istemci, anahtar):
    istemci.get(f"/ornek/{anahtar}")
    assert istemci.get("/bugun").status_code == 200
