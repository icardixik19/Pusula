# Pusula — prototip v0.2

Bu sürümde kurulum akışı (6 adım), seçime göre şekillenen Bugün ekranı ve 3 örnek profil var. Açık ve koyu tema ile sade görünüm de çalışıyor.
Henüz veritabanı, gerçek hesap ve yapay zekâ yok. Seçimler yalnızca tarayıcı oturumunda tutuluyor ve kartlardaki bütün veriler örnek.

## Bilgisayarında çalıştır

```bash
cd pusula
python -m venv .venv
.venv\Scripts\activate          # Windows
# source .venv/bin/activate     # Mac/Linux
pip install -r requirements.txt
copy .env.example .env          # Mac/Linux: cp .env.example .env
```

`.env` içindeki `SECRET_KEY` değerini değiştir. Rastgele bir anahtar üretmek için:
`python -c "import secrets; print(secrets.token_hex(32))"`

```bash
python wsgi.py                  # http://127.0.0.1:5000
python -m pytest -q             # 18 test geçmeli
```

## PythonAnywhere'e yükle

1. Kodu GitHub'a gönder (private repo). `.env` dosyası `.gitignore` sayesinde gitmez.
2. PythonAnywhere'de **Bash** konsolunu aç ve şunları çalıştır:
   ```bash
   git clone https://github.com/KULLANICI/pusula.git
   cd pusula
   python3.12 -m venv ~/.venvs/pusula
   source ~/.venvs/pusula/bin/activate
   pip install -r requirements.txt
   cp .env.example .env && nano .env    # SECRET_KEY'i yaz, SECURE_COOKIES=1 yap
   ```
3. **Web** sekmesinde **Add a new web app** → **Manual configuration** → **Python 3.12** seç.
4. **Virtualenv** alanına `/home/KULLANICI/.venvs/pusula` yaz.
5. **WSGI configuration file** dosyasının içeriğini tamamen silip şunu yaz:
   ```python
   import sys
   yol = "/home/KULLANICI/pusula"
   if yol not in sys.path:
       sys.path.insert(0, yol)
   from wsgi import application
   ```
6. **Static files** bölümüne şu eşlemeyi ekle: URL `/static/`, Directory `/home/KULLANICI/pusula/app/static`
7. **Force HTTPS** seçeneğini aç, ardından **Reload** düğmesine bas.

Güncelleme yapmak için Bash konsolunda `cd ~/pusula && git pull` çalıştır, sonra Web sekmesinde **Reload** düğmesine bas.

## Yapı

```
app/
  core/cards.py      Kart motoru (yapay zekâsız ve belirlenimli sıralama)
  core/modules.py    6 modül, hedefleri, pusula yönleri
  core/gorunum.py    Tema, yoğunluk, örnek profiller
  routes/kurulum.py  Kurulum akışı
  routes/bugun.py    Bugün, Profil, yakında sayfaları
  fixtures/          Örnek kart verileri
  templates/ static/
tests/               18 test (kart motoru ve kurulum)
```

## Bilinen eksikler (sıradaki adımlar)

- Veritabanı (SQLAlchemy + Flask-Migrate) ve gerçek hesap (e-posta ve şifre)
- CSRF koruması (Flask-WTF). Formlar şu an korumasız; gerçek kullanıcı almadan önce zorunlu
- Kartlardaki düğmeler henüz kayıt yapmıyor, yalnızca bilgi mesajı gösteriyor
- Planım ve İlerleme sayfaları
