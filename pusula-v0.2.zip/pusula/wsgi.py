"""PythonAnywhere WSGI girişi.

PythonAnywhere > Web > WSGI configuration file içine şunu yaz
(kullanıcı adını kendi adınla değiştir):

    import sys
    yol = "/home/KULLANICI_ADIN/pusula"
    if yol not in sys.path:
        sys.path.insert(0, yol)
    from wsgi import application
"""
from app import create_app

application = create_app()

if __name__ == "__main__":
    application.run(debug=True)
